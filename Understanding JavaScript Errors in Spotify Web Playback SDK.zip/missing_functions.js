// Add these missing functions to your JS file

/**
 * Checks authentication status with Spotify
 * Verifies if the access token exists and is valid
 */
async function checkAuth() {
  const accessToken = localStorage.getItem('spotify_access_token');
  if (!accessToken) {
    console.log('No access token found');
    return false;
  }
  
  try {
    // Verify token is valid
    const response = await fetch('https://api.spotify.com/v1/me', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    
    if (response.ok) {
      console.log('Token is valid');
      return true;
    } else {
      console.log('Token is invalid or expired');
      localStorage.removeItem('spotify_access_token');
      return false;
    }
  } catch (error) {
    console.error('Error checking auth:', error);
    return false;
  }
}

/**
 * Displays playback status messages
 * Can be used for both UI feedback and console logging
 */
function showPlaybackStatus(message, type = '') {
  console.log(`Playback status: ${message} (${type})`);
  
  // If you have a UI element for status messages (like in your HTML):
  const playbackStatus = document.getElementById('playback-status');
  if (playbackStatus) {
    playbackStatus.textContent = message;
    playbackStatus.className = 'playback-status active';
    
    if (type) {
      playbackStatus.classList.add(type);
    }
    
    // Hide status after a delay
    setTimeout(() => {
      playbackStatus.classList.remove('active');
    }, 3000);
  }
}
