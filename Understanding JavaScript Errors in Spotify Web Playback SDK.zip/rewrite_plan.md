# Comprehensive Rewrite Plan for Spotify AI Music Assistant

## Issues Identified

After reviewing all repository files, I've identified the following issues:

1. **Variable Naming Conflicts**:
   - In chat.js, there's a conflict between `spotifyPlayer` declaration and `player` usage
   - Inconsistent variable naming across files

2. **Missing Function Definitions**:
   - `checkAuth()` function is referenced but not defined
   - `showPlaybackStatus()` function is referenced but not defined

3. **Spotify SDK Integration Issues**:
   - Incorrect SDK initialization order in chat.html
   - Multiple definitions of `onSpotifyWebPlaybackSDKReady` callback
   - Inconsistent SDK script loading across files

4. **Authentication Flow Problems**:
   - Callback.html uses hash fragment for token extraction, but index.html uses query parameters
   - No token refresh mechanism implemented
   - No token expiration handling

5. **Code Organization**:
   - Duplicate code across files
   - Inconsistent structure between index.html and chat.html

## Rewrite Strategy

### 1. File Structure Reorganization

```
spotify-ai-assistant/
├── index.html           # Landing page with login
├── callback.html        # OAuth callback handler
├── chat.html            # Main application interface
├── css/
│   └── styles.css       # Consolidated styles
├── js/
│   ├── auth.js          # Authentication handling
│   ├── player.js        # Spotify player functionality
│   ├── chat.js          # Chat interface functionality
│   └── common.js        # Shared utilities
└── assets/
    └── spotify-logo.png # Logo and other assets
```

### 2. Authentication Module (auth.js)

- Implement proper OAuth PKCE flow
- Add token refresh mechanism
- Handle token expiration
- Provide consistent auth state across pages

### 3. Player Module (player.js)

- Proper Spotify SDK initialization
- Consistent variable naming
- Complete event handling
- Playback control functions

### 4. Chat Module (chat.js)

- Focus on chat UI interaction
- AI response handling
- Message display
- User input processing

### 5. Common Utilities (common.js)

- Shared functions
- Constants
- Helper utilities

## Implementation Plan

### Phase 1: Authentication System

1. Create auth.js with:
   - PKCE authentication flow
   - Token storage and retrieval
   - Token refresh mechanism
   - Auth state management

2. Update callback.html to:
   - Use auth.js for token handling
   - Implement proper error handling
   - Add loading state

### Phase 2: Player Integration

1. Create player.js with:
   - Proper SDK initialization
   - Event listeners
   - Playback controls
   - Device management

2. Ensure consistent SDK loading:
   - Define callback before loading SDK
   - Handle SDK availability checks

### Phase 3: Chat Interface

1. Update chat.js to:
   - Focus on UI interaction
   - Remove player-specific code
   - Improve error handling
   - Enhance user experience

### Phase 4: HTML Structure

1. Update index.html:
   - Clean up structure
   - Proper script loading order
   - Consistent styling

2. Update chat.html:
   - Consistent structure with index.html
   - Proper script loading
   - Improved UI components

### Phase 5: CSS Refinement

1. Consolidate styles.css:
   - Remove duplicates
   - Improve responsiveness
   - Consistent naming conventions

## Testing Strategy

1. Authentication Flow:
   - Test login process
   - Verify token storage
   - Test token refresh
   - Handle authentication errors

2. Player Functionality:
   - Test SDK initialization
   - Verify playback controls
   - Test device selection
   - Handle playback errors

3. Chat Interface:
   - Test message display
   - Verify user input handling
   - Test AI responses
   - Ensure proper error messages

4. Cross-browser Testing:
   - Test on Chrome, Firefox, Safari
   - Verify mobile responsiveness

## Deliverables

1. Complete set of rewritten files
2. Documentation of changes
3. Implementation notes
4. Testing results
